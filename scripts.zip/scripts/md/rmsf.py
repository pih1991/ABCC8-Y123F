#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patheffects import withStroke

def read_rmsf_xvg(filename):
    """Read RMSF .xvg file and return residue index and RMSF values."""
    data = []
    with open(filename, 'r') as f:
        for line in f:
            if line.startswith(('#', '@')):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    idx = int(float(parts[0]))
                    val = float(parts[1])
                    data.append((idx, val))
                except ValueError:
                    continue
    if not data:
        raise ValueError(f"No valid data found in {filename}")
    arr = np.array(data).T
    return arr[0].astype(int), arr[1].astype(float)

def plot_rmsf_dual(residue_labels, rmsf_wt, rmsf_mut, ax, show_avg=True):
    """Plot RMSF for WT and Y123F with publication-ready colors and averages."""
    x = np.arange(len(residue_labels))
    # Colors: soft scientific colors
    color_wt = '#1f77b4'    # muted blue
    color_mut = '#ff7f0e'   # muted orange

    # Smooth path effects
    ax.plot(x, rmsf_wt, linewidth=1.5, color=color_wt, label='WT',
            zorder=3, marker='o', markersize=3, path_effects=[withStroke(linewidth=3, foreground=color_wt, alpha=0.5)])
    ax.plot(x, rmsf_mut, linewidth=1.5, color=color_mut, label='Y123F',
            zorder=3, marker='o', markersize=3, path_effects=[withStroke(linewidth=3, foreground=color_mut, alpha=0.5)])

    # Fill between lines lightly
    ax.fill_between(x, rmsf_wt, alpha=0.1, color=color_wt)
    ax.fill_between(x, rmsf_mut, alpha=0.1, color=color_mut)

    if show_avg:
        avg_wt = np.mean(rmsf_wt)
        avg_mut = np.mean(rmsf_mut)
        ax.axhline(avg_wt, linestyle='--', color=color_wt, linewidth=1.5, alpha=0.7)
        ax.axhline(avg_mut, linestyle='--', color=color_mut, linewidth=1.5, alpha=0.7)
        # Place average labels above figure to prevent overlap
        ax.text(0.02, 1.08, f"WT Avg = {avg_wt:.3f} nm", transform=ax.transAxes,
                ha='left', va='bottom', fontsize=8,
                bbox=dict(boxstyle='round,pad=0.1', fc='white', ec=color_wt, alpha=0.5))
        ax.text(0.60, 1.08, f"Y123F Avg = {avg_mut:.3f} nm", transform=ax.transAxes,
                ha='left', va='bottom', fontsize=8,
                bbox=dict(boxstyle='round,pad=0.1', fc='white', ec=color_mut, alpha=0.5))

    ax.set_xticks(x)
    ax.set_xticklabels(residue_labels, rotation=90, ha='center', fontsize=7)
    ax.set_xlabel("Residue")
    ax.set_ylabel("RMSF (nm)")
    ax.legend(frameon=False)

def create_dual_rmsf_plot(wt_file, mut_file, output="RMSF_dual.png", show_avg=True):
    res_idx_wt, rmsf_wt = read_rmsf_xvg(wt_file)
    res_idx_mut, rmsf_mut = read_rmsf_xvg(mut_file)

    if not np.array_equal(res_idx_wt, res_idx_mut):
        raise ValueError("Residue indices in WT and Y123F files do not match!")

    residue_labels = [str(i) for i in res_idx_wt]

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 12,
        'axes.linewidth': 1.2,
        'figure.dpi': 600,
        'figure.figsize': (12, 4)
    })

    fig, ax = plt.subplots()
    plot_rmsf_dual(residue_labels, rmsf_wt, rmsf_mut, ax, show_avg=show_avg)

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(False)

    plt.tight_layout()
    plt.savefig(output, dpi=600)
    plt.close()
    print(f"Plot saved as {output}")
    print(f"WT Avg RMSF = {np.mean(rmsf_wt):.6f} nm")
    print(f"Y123F Avg RMSF = {np.mean(rmsf_mut):.6f} nm")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Publication-ready RMSF plot for WT and Y123F")
    parser.add_argument("wt_xvg", help="WT RMSF .xvg file")
    parser.add_argument("mut_xvg", help="Y123F RMSF .xvg file")
    parser.add_argument("-o", "--output", default="RMSF_dual.png", help="Output filename")
    parser.add_argument("--no-avg", dest="show_avg", action="store_false", help="Hide average lines/labels")
    args = parser.parse_args()

    create_dual_rmsf_plot(args.wt_xvg, args.mut_xvg, output=args.output, show_avg=args.show_avg)

