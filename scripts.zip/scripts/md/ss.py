# compare_dssp_legend_beside.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# ---------- USER: file paths ----------
wt_file  = "wild-SS.xvg"     # replace with your WT file
mut_file = "mut-SS.xvg"  # replace with your mutant file
# --------------------------------------

cols = [
    "time_ns",
    "Loops", "Breaks", "Bends", "Turns",
    "PP_Helices", "pi_Helices", "3_10_Helices",
    "beta_Strands", "beta_Bridges", "alpha_Helices"
]

def read_xvg(path):
    data = []
    with open(path, "r") as f:
        for line in f:
            if not line.strip() or line.startswith(("@", "#")):
                continue
            parts = line.split()
            vals = [float(p) for p in parts]
            data.append(vals)
    return pd.DataFrame(data, columns=cols)

wt = read_xvg(wt_file)
mut = read_xvg(mut_file)

# If times differ, reindex/interpolate mutant on WT time axis
if not np.allclose(wt["time_ns"].values, mut["time_ns"].values):
    mut = mut.set_index("time_ns").reindex(wt["time_ns"].values).interpolate().reset_index().rename(columns={"index": "time_ns"})

# smoothing (set to 1 to disable)
rolling_window = 5
if rolling_window > 1:
    wt_plot = wt.copy()
    mut_plot = mut.copy()
    wt_plot.iloc[:,1:]  = wt.iloc[:,1:].rolling(window=rolling_window, center=True, min_periods=1).mean()
    mut_plot.iloc[:,1:] = mut.iloc[:,1:].rolling(window=rolling_window, center=True, min_periods=1).mean()
else:
    wt_plot, mut_plot = wt, mut

def percent_df(df):
    ss = df.iloc[:,1:]
    total = ss.sum(axis=1).replace(0, np.nan)
    pct = ss.div(total, axis=0) * 100.0
    pct.insert(0, "time_ns", df["time_ns"].values)
    return pct

wt_pct  = percent_df(wt_plot)
mut_pct = percent_df(mut_plot)

# Order for stacking
stack_order = [
    "Loops", "Turns", "Bends", "Breaks",
    "PP_Helices", "3_10_Helices", "pi_Helices",
    "beta_Bridges", "beta_Strands", "alpha_Helices"
]

# Presentation-friendly palette (high contrast)
palette = [
    "#0B3D91", "#E41A1C", "#4DAF4A", "#984EA3",
    "#FF7F00", "#377EB8", "#F781BF", "#A65628",
    "#999999", "#FFFF33"
]
color_map = {k: palette[i] for i, k in enumerate(stack_order)}

# Plot settings (increase room on right for legend)
plt.rcParams.update({
    "font.size": 12,
    "axes.titlesize": 15,
    "axes.labelsize": 13,
    "legend.fontsize": 11
})

# create figure: keep plotting area narrower so legend fits beside
fig, (ax_wt, ax_mut) = plt.subplots(2, 1, figsize=(12, 8), sharex=True,
                                    gridspec_kw={"height_ratios":[1,1]})

# WT stacked area
ax_wt.stackplot(
    wt_pct["time_ns"],
    [wt_pct[c] for c in stack_order],
    colors=[color_map[c] for c in stack_order],
    edgecolor='none'
)
ax_wt.set_ylabel("% composition", fontsize=13)
ax_wt.set_title("WT", fontsize=15)
ax_mut.set_xlabel("Time (ns)", fontsize=13)
ax_wt.set_ylim(0, 100)

# Mutant stacked area
ax_mut.stackplot(
    mut_pct["time_ns"],
    [mut_pct[c] for c in stack_order],
    colors=[color_map[c] for c in stack_order],
    edgecolor='none'
)
ax_mut.set_ylabel("% composition", fontsize=13)
ax_mut.set_title("Y123F", fontsize=15)
ax_mut.set_xlabel("Time (ns)", fontsize=13)
ax_mut.set_ylim(0, 100)

# Build legend handles (one per SS type) - keep labels intact
legend_handles = [Patch(facecolor=color_map[k], edgecolor='k', label=k, linewidth=0.6) for k in stack_order]

# Place the legend to the right of the figure ("beside the figure")
# Increase subplots' right margin to leave space for the legend
right_space = 0.78   # fraction of figure width reserved for plotting (lower => more room for legend)
plt.subplots_adjust(right=right_space, hspace=0.28, top=0.95, bottom=0.07)

# Use fig.legend with bbox_to_anchor positioned to the right of the plotting area
# bbox_to_anchor uses figure coordinates (0..1). We anchor at x = right_space + small offset.
legend_x = right_space + 0.02
fig.legend(handles=legend_handles,
           loc='center left',
           bbox_to_anchor=(legend_x, 0.5),
           frameon=True,
           ncol=1,
           fontsize=11,
           title="Secondary Structure")

# Save outputs
plt.savefig("dssp_composition_legend_beside.png", dpi=600, bbox_inches='tight')
plt.savefig("dssp_composition_legend_beside.pdf", dpi=600, bbox_inches='tight')
plt.show()

print("Saved: dssp_composition_legend_beside.png and .pdf")

