#!/usr/bin/env python3
"""
Plot RMSD from a GROMACS .xvg file in publication-quality style (no gridlines),
custom x-axis labels, high-res output, and a black RMSD trace with an orange shadow.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

def read_xvg(filename):
    """
    Reads a GROMACS .xvg file, skipping comments and metadata.
    Returns time (ns) and RMSD (nm) as numpy arrays.
    """
    data = []
    with open(filename, 'r') as f:
        for line in f:
            if line.startswith(('#', '@')):
                continue
            parts = line.split()
            if len(parts) >= 2:
                data.append((float(parts[0]), float(parts[1])))
    return np.array(data).T

def plot_rmsd(time, rmsd, output='rmsd_plot.png'):
    """
    Plots RMSD vs. time with:
      - publication-style formatting
      - no gridlines
      - high-res output (600 dpi)
      - black main line
      - orange shadow underneath
      - annotation of mean & SD for t ≥ 1 ns in lower-right
    """
    # Compute mean & SD for t >= 1 ns
    mask = time >= 1.0
    mean_after1 = np.mean(rmsd[mask]) if np.any(mask) else np.nan
    std_after1  = np.std(rmsd[mask])  if np.any(mask) else np.nan

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 12,
        'axes.linewidth': 1.2,
        'axes.labelsize': 14,
        'xtick.direction': 'in',
        'ytick.direction': 'in',
        'xtick.major.size': 5,
        'ytick.major.size': 5,
        'xtick.minor.visible': True,
        'ytick.minor.visible': True,
        'xtick.minor.size': 3,
        'ytick.minor.size': 3,
        'figure.dpi': 600,
        'figure.figsize': (7, 5),
        'axes.facecolor': 'white',
        'savefig.facecolor': 'white',
    })

    fig, ax = plt.subplots()

    # Orange shadow: thick, semi-transparent
    shadow_color = '#D95F02'
    ax.plot(time, rmsd,
            lw=6,
            color=shadow_color,
            alpha=0.3,
            solid_capstyle='round',
            zorder=1)

    # Black main line on top, with orange stroke for extra pop
    line, = ax.plot(time, rmsd,
                    lw=2.0,
                    color='black',
                    zorder=2)
    line.set_path_effects([
        pe.Stroke(linewidth=4, foreground=shadow_color, alpha=0.5),
        pe.Normal()
    ])

    # Remap x-axis ticks
    ticks_ns   = np.arange(0, 12, 2)
    ax.set_xticks(ticks_ns)
    ax.set_xticklabels(labels_pct)

    ax.set_xlabel('Time (ns)')
    ax.set_ylabel('RMSD (nm)')

    # Annotate mean & SD in lower-right
    stats_text = f"Mean = {mean_after1:.3f} nm\nSD   = {std_after1:.3f} nm"
    ax.text(
        0.95, 0.05, stats_text,
        transform=ax.transAxes,
        ha='right', va='bottom',
        fontsize=12,
        bbox=dict(boxstyle='round,pad=0.3',
                  facecolor='white', edgecolor='gray', alpha=0.7)
    )

    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_position(('outward', 2))

    plt.tight_layout()
    plt.savefig(output, dpi=600)
    plt.close(fig)
    print(f'Plot saved as {output} with black RMSD trace and orange shadow.')

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(
        description='Plot RMSD from .xvg with black line, orange shadow, and stats annotation'
    )
    parser.add_argument('xvg_file', help='Input RMSD .xvg file')
    parser.add_argument('-o', '--output', default='rmsd_plot.png',
                        help='Output filename (PNG, PDF, or SVG)')
    args = parser.parse_args()

    t, rmsd = read_xvg(args.xvg_file)
    plot_rmsd(t, rmsd, output=args.output)
