#!/usr/bin/env python3
"""
hbonds_boxplot_mean_above_center.py

Boxplot comparing H-bonds (2nd column) from two .xvg files.
- Clean scientific presentation (viridis colors, no grid, no outliers)
- Only the group mean (numeric) is displayed, positioned slightly above the box center
"""

import argparse
import numpy as np
import matplotlib.pyplot as plt

try:
    import seaborn as sns
    _HAS_SNS = True
except Exception:
    _HAS_SNS = False


def read_second_col_xvg(path):
    vals = []
    with open(path, 'r') as fp:
        for ln in fp:
            ln = ln.strip()
            if not ln or ln.startswith(('#', '@')):
                continue
            parts = ln.split()
            if len(parts) >= 2:
                try:
                    vals.append(float(parts[1]))
                except ValueError:
                    continue
    return np.array(vals, dtype=float)


def get_viridis_palette(n):
    if _HAS_SNS:
        return sns.color_palette("viridis", n_colors=n)
    cmap = plt.get_cmap("viridis")
    if n == 1:
        return [cmap(0.5)]
    return [cmap(i / (n - 1)) for i in range(n)]


def ensure_nonzero_span(ymin, ymax):
    if ymax - ymin < 1e-8:
        ymin -= 0.5
        ymax += 0.5
    return ymin, ymax


def draw_boxplot_mean_above_center(data_list, labels, outpath, fmt='png'):
    n_groups = len(data_list)
    colors = get_viridis_palette(n_groups)

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 11,
        'axes.linewidth': 1.0,
        'figure.dpi': 600,
        'figure.figsize': (6.5, 4.5)
    })

    fig, ax = plt.subplots()
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')

    bp = ax.boxplot(
        data_list,
        patch_artist=True,
        showfliers=False,
        widths=0.6,
        medianprops=dict(color='black', linewidth=1.0),
        whiskerprops=dict(color='black', linewidth=1.0),
        capprops=dict(color='black', linewidth=1.0),
        boxprops=dict(linewidth=0.8)
    )

    for patch, col in zip(bp['boxes'], colors):
        patch.set_facecolor(col)
        patch.set_edgecolor('black')
        patch.set_linewidth(0.8)

    global_min = np.nanmin([np.nanmin(a) for a in data_list if a.size > 0])
    global_max = np.nanmax([np.nanmax(a) for a in data_list if a.size > 0])
    global_min, global_max = ensure_nonzero_span(global_min, global_max)
    vspan = global_max - global_min if global_max > global_min else 1.0

    means = []
    for i, arr in enumerate(data_list, start=1):
        if arr.size == 0:
            means.append(np.nan)
            continue
        q1 = np.percentile(arr, 25)
        q3 = np.percentile(arr, 75)
        center = 0.5 * (q1 + q3)
        m = float(np.mean(arr))
        means.append(m)

        # Shift text slightly upward from center (5% of box height)
        shift = 0.05 * (q3 - q1 if q3 > q1 else vspan * 0.1)
        y_text = center + shift

        ax.text(
            i, y_text, f"{m:.2f}",
            ha='center', va='bottom',
            fontsize=10, color='black', weight='bold', zorder=6
        )

    ax.set_xticks(range(1, n_groups + 1))
    ax.set_xticklabels(labels, fontsize=11)

    y_margin = 0.08 * vspan
    ax.set_ylim(global_min - y_margin, global_max + y_margin)

    ax.set_ylabel("Number of H-bonds", fontsize=12)
    ax.set_title("Number of H-bonds", fontsize=13, fontweight='bold')

    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    if fmt in ('pdf', 'svg'):
        fig.savefig(outpath, format=fmt, bbox_inches='tight')
    else:
        fig.savefig(outpath, dpi=600, bbox_inches='tight', facecolor=fig.get_facecolor())

    plt.close(fig)
    return means


def main():
    p = argparse.ArgumentParser(description="Boxplot of H-bonds with average shown above box center.")
    p.add_argument("file1", help="First .xvg file (e.g. WT)")
    p.add_argument("file2", help="Second .xvg file (e.g. Y123F)")
    p.add_argument("-o", "--output", default="hbonds_mean_box.png", help="Output filename")
    p.add_argument("--labels", nargs=2, default=["WT", "Y123F"], help="Labels for groups")
    p.add_argument("--format", choices=['png', 'pdf', 'svg'], default='png', help="Output format")
    args = p.parse_args()

    a1 = read_second_col_xvg(args.file1)
    a2 = read_second_col_xvg(args.file2)

    if a1.size == 0 and a2.size == 0:
        raise SystemExit("No numeric data found in input files.")

    means = draw_boxplot_mean_above_center([a1, a2], args.labels, args.output, fmt=args.format)
    print(f"Saved {args.output}")
    for lab, arr, m in zip(args.labels, [a1, a2], means):
        print(f"{lab}: n={len(arr)}, mean={m:.4f}")


if __name__ == "__main__":
    main()

