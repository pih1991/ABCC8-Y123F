#!/usr/bin/env python3
"""
mindist_boxplot_mean_above_center.py

Create a publication-ready boxplot for GROMACS mindist outputs (second column).
- Reads the second column from each .xvg (skips comment lines)
- No outliers displayed (showfliers=False)
- No scatter points / no 'n=' labels / no mean lines
- Numeric mean displayed slightly above the vertical center of each box (midpoint of Q1 and Q3)
- Uses seaborn 'viridis' palette if available, otherwise matplotlib's viridis
- Save as PNG/PDF/SVG with non-transparent background
"""

import argparse
import numpy as np
import matplotlib.pyplot as plt

# optional seaborn palette
try:
    import seaborn as sns
    _HAS_SNS = True
except Exception:
    _HAS_SNS = False

def read_second_col_xvg(path):
    """Read numeric values from the second column of an .xvg file (skip comment lines)."""
    vals = []
    with open(path, 'r') as fp:
        for line in fp:
            ln = line.strip()
            if not ln or ln.startswith(('#', '@')):
                continue
            parts = ln.split()
            if len(parts) < 2:
                continue
            try:
                vals.append(float(parts[1]))
            except ValueError:
                # skip non-numeric rows
                continue
    return np.array(vals, dtype=float)

def get_viridis_palette(n):
    """Return n colors sampled from viridis (seaborn if available)."""
    if n <= 0:
        return []
    if _HAS_SNS:
        return sns.color_palette("viridis", n_colors=n)
    cmap = plt.get_cmap("viridis")
    if n == 1:
        return [cmap(0.5)]
    return [cmap(i/(n-1)) for i in range(n)]

def ensure_nonzero_span(ymin, ymax):
    """If ymin==ymax expand a little so boxes are visible."""
    if np.isfinite(ymin) and np.isfinite(ymax):
        if ymax - ymin < 1e-8:
            ymin -= 0.5 if ymin != 0 else 0.5
            ymax += 0.5
    return ymin, ymax

def draw_boxplot_mean_above_center(data_list, labels, outpath, ylabel="Distance (nm)",
                                   title="Minimum distance between chains", fmt='png'):
    """
    Create and save a publication-ready boxplot where the numeric mean is placed
    slightly above the vertical center of each box.
    """
    n_groups = len(data_list)
    colors = get_viridis_palette(n_groups)

    plt.rcParams.update({
        'font.family': 'serif',
        'font.size': 11,
        'axes.linewidth': 1.0,
        'figure.dpi': 600,
        'figure.figsize': (6.5, 4.5)
    })

    fig, ax = plt.subplots()
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')

    # validate
    valid_arrays = [a for a in data_list if (a is not None and a.size > 0)]
    if not valid_arrays:
        raise SystemExit("No numeric data found in input files.")

    # draw boxplot without fliers
    widths = 0.6
    bp = ax.boxplot(data_list,
                    patch_artist=True,
                    showfliers=False,
                    widths=widths,
                    medianprops=dict(color='black', linewidth=1.0),
                    whiskerprops=dict(color='black', linewidth=1.0),
                    capprops=dict(color='black', linewidth=1.0),
                    boxprops=dict(linewidth=0.8))

    # color boxes with black edges
    for patch, col in zip(bp['boxes'], colors[:n_groups]):
        patch.set_facecolor(col)
        patch.set_edgecolor('black')
        patch.set_linewidth(0.8)
        patch.set_alpha(1.0)

    # compute global min/max and ensure nonzero span
    global_min = np.nanmin([np.nanmin(a) for a in data_list if a.size > 0])
    global_max = np.nanmax([np.nanmax(a) for a in data_list if a.size > 0])
    global_min, global_max = ensure_nonzero_span(global_min, global_max)
    vspan = global_max - global_min if global_max > global_min else 1.0

    # For each group: compute Q1,Q3, center=(Q1+Q3)/2, compute mean, place mean slightly above center
    means = []
    for i, arr in enumerate(data_list, start=1):
        if arr.size == 0:
            means.append(np.nan)
            continue
        q1 = np.percentile(arr, 25)
        q3 = np.percentile(arr, 75)
        center = 0.5 * (q1 + q3)
        m = float(np.mean(arr))
        means.append(m)

        # shift number slightly upward from center (5% of box height or fraction of vspan)
        box_height = (q3 - q1) if q3 > q1 else (0.10 * vspan)
        shift = 0.05 * box_height
        y_text = center + shift

        # place numeric mean label (no marker)
        ax.text(i, y_text, f"{m:.2f}", ha='center', va='bottom',
                fontsize=10, color='black', weight='bold', zorder=6)

    # xticks: only labels
    xticks = list(range(1, n_groups + 1))
    ax.set_xticks(xticks)
    ax.set_xticklabels(labels, fontsize=11)

    # y-limits with margin
    y_margin = 0.08 * vspan
    ax.set_ylim(global_min - y_margin, global_max + y_margin)

    # labels & title
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=13, fontweight='bold')

    # clean axes
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    fmt_low = fmt.lower()
    if fmt_low in ('pdf', 'svg'):
        fig.savefig(outpath, format=fmt_low, bbox_inches='tight')
    else:
        fig.savefig(outpath, dpi=600, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close(fig)
    return means

def main():
    p = argparse.ArgumentParser(description="Boxplot of GROMACS mindist outputs with mean number above box center.")
    p.add_argument("file1", help="First .xvg file (e.g. WT_mindist.xvg)")
    p.add_argument("file2", help="Second .xvg file (e.g. Mutant_mindist.xvg)")
    p.add_argument("-o", "--output", default="mindist_boxplot.png", help="Output filename")
    p.add_argument("--labels", nargs=2, default=["WT", "Y123F"], help="Labels for the two boxes")
    p.add_argument("--ylabel", default="Minimum distance (nm)", help="Y-axis label")
    p.add_argument("--title", default="Minimum distance between chains", help="Plot title")
    p.add_argument("--format", choices=['png', 'pdf', 'svg'], default='png', help="Output file format")
    args = p.parse_args()

    a1 = read_second_col_xvg(args.file1)
    a2 = read_second_col_xvg(args.file2)

    if a1.size == 0 and a2.size == 0:
        raise SystemExit("No numeric data found in either input file.")

    means = draw_boxplot_mean_above_center([a1, a2], args.labels, args.output,
                                           ylabel=args.ylabel, title=args.title, fmt=args.format)
    print(f"Saved {args.output}")
    for lab, arr, m in zip(args.labels, [a1, a2], means):
        print(f"{lab}: n={len(arr)}, mean={m:.4f}")

if __name__ == "__main__":
    main()

