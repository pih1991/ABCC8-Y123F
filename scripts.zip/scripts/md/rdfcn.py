import numpy as np
import matplotlib.pyplot as plt

# Files
wt_file = "wild-rdf.xvg"
mut_file = "mut-rdf.xvg"

# Colors
color_wt = "#1f77b4"   # Blue
color_mut = "#ff7f0e"  # Orange

# Read XVG files (cumulative water number)
def read_xvg(file, cutoff=1.0):
    data = []
    r_vals = []
    with open(file, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith(("#", "@")) or len(line) == 0:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue
            r = float(parts[0])
            n = float(parts[1])
            if r <= cutoff:
                r_vals.append(r)
                data.append(n)
            else:
                break
    return np.array(r_vals), np.array(data)

r_wt, wt_vals = read_xvg(wt_file)
r_mut, mut_vals = read_xvg(mut_file)

# Plot
plt.figure(figsize=(6,5))
plt.plot(r_wt, wt_vals, color=color_wt, label="WT", linewidth=2)
plt.plot(r_mut, mut_vals, color=color_mut, label="Y123F", linewidth=2)

# Optional: filled area under curve for emphasis
plt.fill_between(r_wt, 0, wt_vals, color=color_wt, alpha=0.1)
plt.fill_between(r_mut, 0, mut_vals, color=color_mut, alpha=0.1)

plt.xlabel("Distance from protein (nm)")
plt.ylabel("Cumulative number of water molecules")
plt.title("Water molecules around protein (r ≤ 1 nm)")
plt.legend()
plt.tight_layout()

# Save figures
plt.savefig("waters_cumulative_1nm.png", dpi=600)
plt.savefig("waters_cumulative_1nm.pdf")

plt.show()

