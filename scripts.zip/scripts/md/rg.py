#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patheffects import withStroke
from scipy.ndimage import uniform_filter1d
import argparse

# ---------------------------
# Functions
# ---------------------------

def read_rg_xvg(filename):
    """Read Rg .xvg file, convert time from ps to ns."""
    times, rg_values = [], []
    with open(filename, 'r') as f:
        for line in f:
            if line.startswith(('#', '@')):
                continue
            parts = line.split()
            if len(parts) >= 2:
                try:
                    times.append(float(parts[0]) / 1000.0)  # ps -> ns
                    rg_values.append(float(parts[1]))
                except ValueError:
                    continue
    if not times:
        raise ValueError(f"No valid data found in {filename}")
    return np.array(times), np.array(rg_values)

def plot_rg_dual(time_wt, rg_wt, time_mut, rg_mut, ax, smooth_window=5, show_avg=True):
    """Plot WT and Mutant Rg on the same axes."""
    
    # Smooth
    rg_wt_smooth = uniform_filter1d(rg_wt, size=smooth_window)
    rg_mut_smooth = uniform_filter1d(rg_mut, size=smooth_window)

    # Colors (light, journal-friendly)
    color_wt = '#4C72B0'   # soft blue
    color_mut = '#DD8452'  # soft orange
    stroke_color_wt = '#A6CEE3'
    stroke_color_mut = '#FFBC99'

    # Plot lines with soft stroke and transparency
    line_wt, = ax.plot(time_wt, rg_wt_smooth, color=color_wt, linewidth=2.5, alpha=0.85, zorder=2)
    line_wt.set_path_effects([withStroke(linewidth=4, foreground=stroke_color_wt, alpha=0.5)])
    line_mut, = ax.plot(time_mut, rg_mut_smooth, color=color_mut, linewidth=2.5, alpha=0.85, zorder=2)
    line_mut.set_path_effects([withStroke(linewidth=4, foreground=stroke_color_mut, alpha=0.5)])

    # Average lines
    if show_avg:
        avg_wt = np.mean(rg_wt)
        avg_mut = np.mean(rg_mut)
        ax.axhline(avg_wt, linestyle='--', color=color_wt, linewidth=1.5, alpha=0.7)
        ax.axhline(avg_mut, linestyle='--', color=color_mut, linewidth=1.5, alpha=0.7)

        # Move text annotation above the figure
        ax.text(0.02, 1.08, f"WT Avg = {avg_wt:.3f} nm", transform=ax.transAxes,
                ha='left', va='bottom', fontsize=8,
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec=color_wt, alpha=0.5))
        ax.text(0.75, 1.08, f"Y123F Avg = {avg_mut:.3f} nm", transform=ax.transAxes,
                ha='left', va='bottom', fontsize=8,
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec=color_mut, alpha=0.5))

    # X-ticks: exactly 6 evenly spaced ticks
    num_ticks = 6
    x_min, x_max = min(time_wt[0], time_mut[0]), max(time_wt[-1], time_mut[-1])
    x_ticks = np.linspace(x_min, x_max, num=num_ticks)
    ax.set_xticks(x_ticks)
    ax.set_xticklabels([f"{t:.1f}" for t in x_ticks], fontsize=11)

    # Y-axis dynamic
    y_min = min(rg_wt_smooth.min(), rg_mut_smooth.min())
    y_max = max(rg_wt_smooth.max(), rg_mut_smooth.max())
    y_margin = 0.05 * (y_max - y_min)
    ax.set_ylim(y_min - y_margin, y_max + y_margin)

    # Labels
    ax.set_xlabel("MD Time (ns)", fontsize=12)
    ax.set_ylabel("Radius of Gyration (nm)", fontsize=12)

    # Clean axes
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Legend outside
    ax.legend(["WT", "Y123F"], frameon=False, fontsize=10, loc='upper left', bbox_to_anchor=(1.02, 1))

def create_dual_rg_plot(wt_file, mut_file, output="Rg_dual_plot.png", smooth_window=5, show_avg=True):
    time_wt, rg_wt = read_rg_xvg(wt_file)
    time_mut, rg_mut = read_rg_xvg(mut_file)

    plt.rcParams.update({
        "font.family": "serif",
        "figure.figsize": (10, 5),
        "figure.dpi": 600,
        "axes.linewidth": 1.2,
        "font.size": 12
    })
    fig, ax = plt.subplots()
    plot_rg_dual(time_wt, rg_wt, time_mut, rg_mut, ax, smooth_window=smooth_window, show_avg=show_avg)
    plt.tight_layout()
    plt.savefig(output, dpi=600)
    plt.savefig(output.replace(".png", ".pdf"), dpi=600, bbox_inches='tight')
    plt.close()
    print(f"Plot saved as {output}")
    print(f"Average Rg WT = {np.mean(rg_wt):.6f} nm")
    print(f"Average Rg Y123F = {np.mean(rg_mut):.6f} nm")

# ---------------------------
# Main
# ---------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dual Rg plot for WT and Y123F (journal-quality).")
    parser.add_argument("--wt", required=True, help="WT Rg .xvg file")
    parser.add_argument("--mut", required=True, help="Y123F Rg .xvg file")
    parser.add_argument("-o", "--output", default="Rg_dual_plot.png", help="Output filename")
    parser.add_argument("--smooth", type=int, default=5, help="Window size for smoothing")
    parser.add_argument("--no-avg", dest="show_avg", action="store_false", help="Hide average lines")
    args = parser.parse_args()

    create_dual_rg_plot(args.wt, args.mut, output=args.output, smooth_window=args.smooth, show_avg=args.show_avg)

