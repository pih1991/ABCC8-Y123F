import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Read the CSV
df = pd.read_csv('ALL.csv')

# 2. Clean column names to match figure (strip spaces)
df.columns = df.columns.str.strip()

# 3. Print columns to check if loaded correctly (optional)
print(df.columns)

# 4. Define heatmap data using exact column names and rows
heatmap_data = df.set_index('Mutation')[
    ['ddg_monomer (REU)', 'MP-DDG (REU)', 'FoldX (kcal/mol)', 'Flex-ddG (REU)', 'DDMut-PPI (kcal/mol)']
]

# 5. Plot heatmap
plt.figure(figsize=(10, max(5, 0.3 * len(heatmap_data))))
im = plt.imshow(
    heatmap_data.values,
    aspect='auto',
    cmap='coolwarm',
    interpolation='nearest'
)

# 6. Set ticks and labels
plt.xticks(
    np.arange(heatmap_data.shape[1]),
    heatmap_data.columns,
    rotation=45,
    ha='right',
    fontsize=12
)
plt.yticks(
    np.arange(heatmap_data.shape[0]),
    heatmap_data.index,
    fontsize=12
)

plt.ylabel('Mutation', fontsize=16)

# 7. Add colorbar
cbar = plt.colorbar(im, shrink=0.8)
cbar.set_label('Energy', fontsize=16)
cbar.ax.tick_params(labelsize=12)

# 8. Adjust layout and save/show
plt.tight_layout()
plt.savefig('mutation_energy_heatmap.png', dpi=600)
plt.show()

