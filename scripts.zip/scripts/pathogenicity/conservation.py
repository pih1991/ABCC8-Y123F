import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Sample data
data = {
    'Position': [123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133],
    'Residue': ['Y', 'Y', 'H', 'N', 'I', 'E', 'T', 'S', 'N', 'F', 'P'],
    'Score': [0.129, 0.024, 0.024, 0.024, 0.107, 0.107, 0.099, 0.178, 0.155, 0.136, 0.136]
}

df = pd.DataFrame(data)

plt.figure(figsize=(10, 2))

# Normalize scores to 0-1
norm_scores = df['Score'] / df['Score'].max()

# Use coolwarm colormap (red to blue)
colors = plt.cm.coolwarm(norm_scores)

plt.bar(
    x=df['Position'].astype(str),
    height=1,
    color=colors,
    edgecolor='black'
)

for i, (pos, res, score) in enumerate(zip(df['Position'], df['Residue'], df['Score'])):
    plt.text(i, 0.5, f"{res}\n{score:.3f}", ha='center', va='center', fontsize=13, color='black', weight='bold')

plt.xlabel('Position')
plt.title('Score Heatmap per Position (Red to Blue)')
plt.yticks([])
plt.ylim(0, 1)
plt.tight_layout()
plt.show()

