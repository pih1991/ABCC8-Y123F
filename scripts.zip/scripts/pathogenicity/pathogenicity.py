import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import Normalize
import matplotlib.cm as cm

# Load your CSV file
df = pd.read_csv('alphamissense.csv')

# Normalize score values for colormap
norm = Normalize(vmin=0, vmax=1)
colors = cm.coolwarm(norm(df['Score']))

# Prepare the figure
num_mutations = len(df)
fig_width = max(12, num_mutations * 0.6)
fig, ax = plt.subplots(figsize=(fig_width, 3))

# Plot each mutation block
for i, (mutation, score, status) in enumerate(zip(df['Mutation'], df['Score'], df['Status'])):
    # Colored square
    rect = plt.Rectangle((i, 0), 1, 1, color=cm.coolwarm(norm(score)), edgecolor='black')
    ax.add_patch(rect)

    # Mutation label (top center)
    ax.text(i + 0.5, 0.75, mutation,
            ha='center', va='center',
            fontsize=10, weight='bold', color='black')

    # Status label (bottom center, rotated 90°)
    ax.text(i + 0.9, 0.15, status,
            ha='right', va='center',
            fontsize=13, color='black', rotation=90, style='italic')

# Remove axes ticks/labels
ax.set_xlim(0, num_mutations)
ax.set_ylim(0, 1)
ax.axis('off')

# Add colorbar
sm = cm.ScalarMappable(cmap='coolwarm', norm=norm)
sm.set_array([])
cbar = fig.colorbar(sm, ax=ax, orientation='vertical', shrink=0.6)
cbar.set_label('AlphaMissense Score', fontsize=12)

# Title and layout
plt.title('AlphaMissense Heatmap for ABCC8 Tyr123 Mutations', fontsize=14, weight='bold')
plt.tight_layout()
plt.show()

