#!/bin/bash

path_to_PDB="./relaxed.pdb"

output_dir="./relaxed"
if [ ! -d $output_dir ]
then
    mkdir -p $output_dir
fi

chains_to_design="A"

python ./protein_mpnn_run.py \
        --pdb_path $path_to_PDB \
        --pdb_path_chains "$chains_to_design" \
        --out_folder $output_dir \
        --num_seq_per_target 20 \
        --sampling_temp "0.1" \
        --score_only 1 \
        --seed 37 \
        --batch_size 1
