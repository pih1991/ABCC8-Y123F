import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. Read the CSV
df = pd.read_csv('pro.csv')

# 2. Prepare heatmap data with the exact column names
heatmap_data = df.set_index('Mutation')[
    ['ProteinMPNN', 'ESM', 'MIF-ST']  # normal hyphen here
]

# 3. Plot
plt.figure(figsize=(8, max(4, 0.3 * len(heatmap_data))))
im = plt.imshow(
    heatmap_data.values,
    aspect='auto',
    cmap='coolwarm',
    interpolation='nearest'
)

# 4. Labels & ticks
plt.xticks(
    np.arange(heatmap_data.shape[1]),
    heatmap_data.columns,
    rotation=45,
    ha='right',
    fontsize=14
)
plt.yticks(
    np.arange(heatmap_data.shape[0]),
    heatmap_data.index,
    fontsize=14
)

plt.ylabel('Mutation', fontsize=16)

# 5. Colorbar
cbar = plt.colorbar(im, shrink=0.8)
cbar.set_label('Score', fontsize=16)
cbar.ax.tick_params(labelsize=12)

# 6. Save & show
plt.tight_layout()
plt.savefig('pro_mutation_score_heatmap.png', dpi=600)
plt.show()
