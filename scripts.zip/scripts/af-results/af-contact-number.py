#!/usr/bin/env python3
"""
protein_violin_slices.py

Alternative violin-plot renderer for publication figures.

- Loads cn.csv (skips the first row, renames columns, drops fully-empty rows,
  removes last row assumed to be averages).
- Creates two separate violin plots (Contact number, actifpTM).
- Each violin is filled with a smooth vertical red->blue gradient using
  horizontal slicing of the violin polygon.
- Means are shown as dashed black lines; individual points are overlaid with jitter.
- Clean white background (no gridlines). Saves high-resolution PNGs.

Outputs:
  - contact_violin_alt.png
  - actifp_violin_alt.png
"""

from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.path import Path as MplPath
from matplotlib.patches import Polygon

# ---------- Configuration ----------
INPUT_CSV = "cn.csv"                       # input CSV file (in working dir)
OUT_CONTACT = "contact_violin_alt.png"
OUT_ACTIFP = "actifp_violin_alt.png"
FIGSIZE = (4.5, 6)                         # inches (width, height)
DPI = 300                                  # PNG DPI (publication quality)
N_SLICES = 250                             # number of horizontal gradient slices (higher -> smoother)
RANDOM_SEED = 0
np.random.seed(RANDOM_SEED)


# ---------- Data loading / cleaning ----------
def load_and_clean(filepath: str) -> pd.DataFrame:
    """
    Load CSV skipping first row, rename columns to expected names,
    drop fully-empty rows, and remove last row (assumed averages).
    """
    df = pd.read_csv(filepath, skiprows=1)
    # rename columns according to your file layout
    df.columns = ["Wild_Contact", "Wild_actifpTM", "Mutant_Contact", "Mutant_actifpTM"]
    df = df.dropna(how="all").reset_index(drop=True)
    if len(df) >= 1:
        df = df.iloc[:-1].reset_index(drop=True)
    return df


# ---------- Geometry helpers ----------
def polygon_x_intersections(verts: np.ndarray, y: float) -> List[float]:
    """
    Given an Nx2 array of polygon vertices (x, y), compute x-intersections
    of the polygon with a horizontal line at y. Returns list of x coordinates
    where the polygon boundary crosses that horizontal line.
    """
    xs = []
    for (x0, y0), (x1, y1) in zip(verts[:-1], verts[1:]):
        # check if segment crosses horizontal line at y (strict between or touching)
        if (y0 <= y <= y1) or (y1 <= y <= y0):
            if y1 == y0:
                # horizontal segment — ignore or include endpoints depending on situation
                continue
            # linear interpolation for x at this y
            t = (y - y0) / (y1 - y0)
            x_at_y = x0 + t * (x1 - x0)
            xs.append(float(x_at_y))
    return xs


def fill_violin_gradient_by_slices(ax, body_path: MplPath, cmap, n_slices: int = 200):
    """
    Fill an arbitrary violin body polygon (given as a Matplotlib Path) with a
    vertical gradient by drawing many thin horizontal polygons.
    """
    verts = np.array(body_path.vertices)
    y_min, y_max = verts[:, 1].min(), verts[:, 1].max()
    if not np.isfinite(y_min) or not np.isfinite(y_max) or y_min == y_max:
        return  # nothing to draw

    ys = np.linspace(y_min, y_max, n_slices + 1)

    # for each slice band between ys[i] and ys[i+1], compute center y and find left/right
    for i in range(n_slices):
        y0, y1 = ys[i], ys[i + 1]
        ymid = 0.5 * (y0 + y1)
        xs = polygon_x_intersections(verts, ymid)
        if len(xs) < 2:
            # no crossing at this ymid
            continue
        xs_sorted = sorted(xs)
        # For complex polygons there can be >2 intersections; take leftmost and rightmost
        x_left = xs_sorted[0]
        x_right = xs_sorted[-1]
        # Build a horizontal slice polygon (rectangle spanning x_left->x_right at y0->y1)
        poly_coords = [(x_left, y0), (x_right, y0), (x_right, y1), (x_left, y1)]
        # color from colormap: map ymid in [y_min, y_max] to [0,1]
        t = (ymid - y_min) / (y_max - y_min)
        facecolor = cmap(t)
        poly = Polygon(poly_coords, closed=True, facecolor=facecolor, edgecolor="none", linewidth=0.0, zorder=2)
        ax.add_patch(poly)


# ---------- Plotting ----------
def plot_violin_slices(
    data_lists: List[np.ndarray],
    labels: List[str],
    var_label: str,
    out_png: str,
    n_slices: int = N_SLICES,
    figsize: Tuple[float, float] = FIGSIZE,
    dpi: int = DPI,
):
    """
    Create violin plots for data_lists (one list per violin) at x positions 0..len-1,
    fill them with a vertical red->blue gradient using slicing, overlay jittered points,
    and draw mean lines. Save to PNG.
    """
    sns.set_style("white")
    sns.set_context("paper")

    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)

    # Use matplotlib violinplot to compute the body paths (we will fill them)
    positions = np.arange(len(data_lists))
    vp = ax.violinplot(data_lists, positions=positions, widths=0.7, showmeans=False, showmedians=False, showextrema=False)

    # Build RdBu colormap (red->blue)
    cmap = plt.get_cmap("RdBu")

    # For each violin body, fill using many horizontal slices
    # Matplotlib's violinplot creates 'bodies' in vp['bodies'], their paths define the polygons
    for i, body in enumerate(vp["bodies"]):
        path = body.get_paths()[0]  # Matplotlib Path
        # Fill with slices
        fill_violin_gradient_by_slices(ax, path, cmap, n_slices=n_slices)
        # hide the original body fill/edge
        body.set_edgecolor("none")
        body.set_facecolor("none")

    # Overlay jittered points (black)
    long_rows = []
    for lab, arr in zip(labels, data_lists):
        for val in arr:
            long_rows.append((lab, val))
    df_long = pd.DataFrame(long_rows, columns=["Group", "Value"])
    order = labels
    sns.stripplot(x="Group", y="Value", data=df_long, order=order, color="k", size=4, jitter=0.12, alpha=0.75, zorder=4, ax=ax)

    # Draw mean lines
    for i, arr in enumerate(data_lists):
        if len(arr) > 0:
            mean_val = float(np.nanmean(arr))
            ax.hlines(mean_val, i - 0.18, i + 0.18, colors="k", linestyles="--", linewidth=1.4, zorder=5)

    # Labels and aesthetics
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel(var_label, fontsize=11)
    ax.set_xlabel("")
    ax.set_title(f"{var_label}: Wild vs Mutant", fontsize=12, weight="bold")
    sns.despine(trim=False, top=True, right=True)

    fig.tight_layout()
    fig.savefig(out_png, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


# ---------- Main ----------
def main():
    p = Path(INPUT_CSV)
    if not p.exists():
        raise FileNotFoundError(f"Input CSV not found: {p.resolve()}")

    df = load_and_clean(str(p))

    # Prepare arrays for Contact number
    wild_contact = pd.to_numeric(df["Wild_Contact"], errors="coerce").dropna().values
    mutant_contact = pd.to_numeric(df["Mutant_Contact"], errors="coerce").dropna().values

    plot_violin_slices(
        data_lists=[wild_contact, mutant_contact],
        labels=["Wild", "Mutant"],
        var_label="Contact number",
        out_png=OUT_CONTACT,
        n_slices=N_SLICES,
    )

    # Prepare arrays for actifpTM
    wild_act = pd.to_numeric(df["Wild_actifpTM"], errors="coerce").dropna().values
    mutant_act = pd.to_numeric(df["Mutant_actifpTM"], errors="coerce").dropna().values

    plot_violin_slices(
        data_lists=[wild_act, mutant_act],
        labels=["Wild", "Mutant"],
        var_label="actifpTM",
        out_png=OUT_ACTIFP,
        n_slices=N_SLICES,
    )

    print("Saved:", OUT_CONTACT, "and", OUT_ACTIFP)


if __name__ == "__main__":
    main()
