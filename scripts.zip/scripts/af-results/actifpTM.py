#!/usr/bin/env python3
"""
plot_actifptm.py

Loads mutc1024.csv and plots only the actifpTM metric.
Creates:
 - actifptm_line.png : scatter ("dot") plot across complexes (no connecting line)
 - actifptm_heatmap.png : heatmap-style column of actifpTM values
"""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

# ---------------------------
# Configuration
# ---------------------------
OUT_LINE = "actifptm_line.png"
OUT_HEAT = "actifptm_heatmap.png"
FIG_DPI = 300
FIGSIZE_DOT = (10, 5)
FIGSIZE_HEAT = (4, max(4, 0.25 * 20))  # height will scale with number of rows
FONT_LABEL = 12
# decreased tick label size specifically for dot plot as requested
FONT_TICKS_SMALL = 8
# marker / dot settings
DOT_SIZE = 40   # marker area
DOT_EDGEWIDTH = 0.4
DOT_ALPHA = 0.95
JITTER_STD = 0.08

# unified colormap: dark red -> dark blue (used for both dot plot colorbar and heatmap)
DARK_RED_DARK_BLUE = LinearSegmentedColormap.from_list("darkred_darkblue", ["#8B0000", "#00008B"])

# global rc params
plt.rcParams['figure.dpi'] = FIG_DPI
plt.rcParams['axes.labelsize'] = FONT_LABEL
plt.rcParams['legend.fontsize'] = FONT_TICKS_SMALL

# use seaborn theme but we'll remove grid for the dot plot explicitly
sns.set_theme(style='white')

# ---------------------------
# Load CSV
# ---------------------------
try:
    df = pd.read_csv(CSV_PATH)
except Exception as e:
    print(f"Error reading '{CSV_PATH}': {e}", file=sys.stderr)
    sys.exit(1)

# Normalize column names (strip, lowercase)
df.columns = df.columns.str.strip().str.lower()

# Detect id (complex) column
if 'complex' in df.columns:
    id_col = 'complex'
else:
    id_col = df.columns[0]  # fallback to first column
    print(f"Warning: 'complex' column not found. Using '{id_col}' as x-axis.")

# Detect actifptm column (look for 'actif' or 'actifptm' in name)
actif_col = None
for c in df.columns:
    if 'actif' in c:
        actif_col = c
        break

if actif_col is None:
    print("Error: could not find a column containing 'actif' in the header.", file=sys.stderr)
    print("Available columns:", df.columns.tolist(), file=sys.stderr)
    sys.exit(1)

print(f"Using x-axis = '{id_col}', actif column = '{actif_col}'")

# Ensure numeric
df[actif_col] = pd.to_numeric(df[actif_col], errors='coerce')

# Prepare index for plotting
if pd.api.types.is_numeric_dtype(df[id_col]) or df[id_col].astype(str).str.isnumeric().all():
    # keep numeric ordering
    df[id_col] = pd.to_numeric(df[id_col], errors='coerce').astype('Int64')
    df = df.sort_values(by=id_col)
    x_labels = df[id_col].astype(str).tolist()
else:
    # keep original order; convert to string for nicer labels
    df[id_col] = df[id_col].astype(str)
    x_labels = df[id_col].tolist()

df_plot = df[[id_col, actif_col]].dropna(subset=[actif_col]).copy()
# integer positions for x but show original labels
x_positions = np.arange(1, len(df_plot) + 1)

# ---------------------------
# Dot plot (scatter, jittered)
# - No connecting line
# - Jitter horizontally so dots don't stack
# - Colorbar: dark red -> dark blue
# - Smaller tick label sizes for x and y
# - NO background gridlines for this plot
# ---------------------------
np.random.seed(0)  # reproducible jitter
x_jitter = x_positions + np.random.normal(loc=0.0, scale=JITTER_STD, size=len(x_positions))
y = df_plot[actif_col].values

fig, ax = plt.subplots(figsize=FIGSIZE_DOT)
sc = ax.scatter(
    x_jitter, y,
    c=y,
    cmap=DARK_RED_DARK_BLUE,
    s=DOT_SIZE,
    edgecolor='k',
    linewidth=DOT_EDGEWIDTH,
    alpha=DOT_ALPHA
)

# remove background lines / grid for this dot plot
ax.grid(False)

ax.set_xlabel('Complex', fontsize=FONT_LABEL)
ax.set_ylabel('actifpTM', fontsize=FONT_LABEL)
ax.set_title('actifpTM across complexes (scatter, jittered)', fontsize=FONT_LABEL + 2)

# set ticks to integer positions but show original labels
ax.set_xticks(x_positions)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=FONT_TICKS_SMALL)
ax.tick_params(axis='y', labelsize=FONT_TICKS_SMALL)

# colorbar for dot plot uses the dark red -> dark blue colormap
cbar = plt.colorbar(sc, ax=ax)
cbar.set_label('actifpTM', fontsize=FONT_TICKS_SMALL)
cbar.ax.tick_params(labelsize=FONT_TICKS_SMALL)

plt.tight_layout()
plt.savefig(OUT_LINE, dpi=FIG_DPI, bbox_inches='tight')
print(f"Saved dot/scatter plot to {OUT_LINE}")
plt.show()

# ---------------------------
# Heatmap (single-column)
# - use the same dark red -> dark blue colormap
# - keep annot size modest
# ---------------------------
plt.figure(figsize=FIGSIZE_HEAT)
ax = sns.heatmap(
    df_plot[[actif_col]],
    cmap=DARK_RED_DARK_BLUE,
    annot=True,
    fmt=".3f",
    cbar_kws={'label': 'actifpTM'},
    linewidths=0.5,
    linecolor='white',
    annot_kws={"size": FONT_TICKS_SMALL, "weight": 'bold', "color": 'black'},
    cbar=True
)
ax.set_ylabel('Complex', fontsize=FONT_LABEL)
ax.set_xlabel('')
ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=FONT_TICKS_SMALL)
ax.set_xticklabels([actif_col], rotation=45, fontsize=FONT_TICKS_SMALL)
plt.title('actifpTM heatmap', fontsize=FONT_LABEL + 1)
plt.tight_layout()
plt.savefig(OUT_HEAT, dpi=FIG_DPI, bbox_inches='tight')
print(f"Saved heatmap to {OUT_HEAT}")
plt.show()

