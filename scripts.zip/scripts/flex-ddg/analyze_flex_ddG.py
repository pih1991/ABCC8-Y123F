#!/usr/bin/env python3
"""
Refined Rosetta ddG Analysis Script for Python 3.12+
"""
import argparse
import logging
import sqlite3
from pathlib import Path
import pandas as pd
import numpy as np

# Constants
ROSETTA_OUTPUT_NAME = 'rosetta.out'
OUTPUT_DB_NAME = 'ddG.db3'
TRAJ_STRIDE = 5
OUTPUT_DIR = Path('analysis_output')

ZEMU_GAM_PARAMS = {
    'fa_sol':      (6.940, -6.722),
    'hbond_sc':    (1.902, -1.999),
    'hbond_bb_sc': (0.063,  0.452),
    'fa_rep':      (1.659, -0.836),
    'fa_elec':     (0.697, -0.122),
    'hbond_lr_bb': (2.738, -1.179),
    'fa_atr':      (2.313, -1.649),
}

def gam_function(x: float, term: str) -> float:
    a, b = ZEMU_GAM_PARAMS[term]
    return -np.exp(a) + 2 * np.exp(a) / (1 + np.exp(-x * np.exp(b)))

def apply_zemu_gam(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    terms = list(ZEMU_GAM_PARAMS)
    for term in terms:
        if term not in df.columns:
            raise KeyError(f"Missing column '{term}' for GAM transformation")
        df[term] = df[term].apply(lambda x: gam_function(x, term))
    df['total_score'] = df[terms].sum(axis=1)
    df['score_function_name'] = df['score_function_name'] + '-gam'
    return df

def rosetta_output_succeeded(dirpath: Path) -> bool:
    out = dirpath / ROSETTA_OUTPUT_NAME
    db = dirpath / OUTPUT_DB_NAME
    if not out.exists() or not db.exists():
        return False
    success = done = False
    for line in out.read_text().splitlines():
        if 'JobDistributor' in line and 'reported success in' in line:
            success = True
        if 'JobDistributor' in line and 'no more batches to process' in line:
            done = True
    return success and done

def find_finished_jobs(root: Path) -> dict[Path, list[Path]]:
    jobs = {}
    for job in root.iterdir():
        if not job.is_dir():
            continue
        finished = [s for s in sorted(job.iterdir()) if s.is_dir() and rosetta_output_succeeded(s)]
        jobs[job] = finished
    return jobs

def get_scores_from_db(db_file: Path, struct_num: int, case: str) -> pd.DataFrame:
    conn = sqlite3.connect(db_file)
    conn.row_factory = sqlite3.Row
    max_batch = conn.cursor().execute('SELECT max(batch_id) FROM batches').fetchone()[0]
    query = '''
    SELECT b.name, ss.struct_id, st.score_type_name,
           ss.score_value, sf.score_function_name
    FROM structure_scores ss
      JOIN batches b ON b.batch_id=ss.batch_id
      JOIN score_function_method_options sf ON sf.batch_id=b.batch_id
      JOIN score_types st ON st.batch_id=ss.batch_id AND st.score_type_id=ss.score_type_id;
    '''
    df = pd.read_sql(query, conn)
    conn.close()
    df['backrub_steps'] = df['struct_id'].apply(lambda sid: TRAJ_STRIDE * (1 + (int(sid-1) // max_batch)))
    df['state'] = df['name'].str.replace(r'_dbreport$', '', regex=True)
    pivot = df.pivot_table(
        index=['state', 'backrub_steps', 'score_function_name'],
        columns='score_type_name',
        values='score_value'
    ).reset_index()
    pivot['struct_num'] = struct_num
    pivot['case_name'] = case
    return pivot

def process_struct(path: Path, case: str) -> pd.DataFrame:
    db = path / OUTPUT_DB_NAME
    if not db.exists():
        raise FileNotFoundError(f"Database not found: {db}")
    return get_scores_from_db(db, int(path.name), case)

def calc_ddg(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    maxn = df['struct_num'].max()
    thresholds = sorted({maxn} | {i for i in range(10, int(maxn)) if i % 10 == 0})
    all_ddg = []
    full_struct = pd.DataFrame()
    non_key_cols = [c for c in df.columns if c not in ['case_name','backrub_steps','struct_num','score_function_name','state']]
    for n in thresholds:
        sub = df[df['struct_num'] <= n]
        p1 = sub[sub['state'].isin(['unbound_mut', 'bound_wt'])].copy()
        p1[non_key_cols] *= -1
        p2 = sub[sub['state'].isin(['unbound_wt', 'bound_mut'])].copy()
        comb = pd.concat([p1, p2], ignore_index=True)
        grp_sum = comb.groupby(['case_name','backrub_steps','struct_num','score_function_name'])[non_key_cols].sum().reset_index()
        if n == maxn:
            full_struct = grp_sum.copy()
        grp_mean = grp_sum.groupby(['case_name','backrub_steps','score_function_name'])[non_key_cols].mean().round(5).reset_index()
        grp_mean['nstruct'] = n
        grp_mean['scored_state'] = 'ddG'
        all_ddg.append(grp_mean)
    return pd.concat(all_ddg, ignore_index=True), full_struct

def calc_dgs(df: pd.DataFrame) -> list[pd.DataFrame]:
    out = []
    maxn = df['struct_num'].max()
    thresholds = sorted({maxn} | {i for i in range(10, int(maxn)) if i % 10 == 0})
    non_key_cols = [c for c in df.columns if c not in ['case_name','backrub_steps','struct_num','score_function_name','state']]
    for state in ['wt', 'mut']:
        for n in thresholds:
            sub = df[(df['state'].str.endswith(state)) & (df['struct_num'] <= n)]
            unb = sub[sub['state'].str.startswith('unbound')].copy()
            bnd = sub[sub['state'].str.startswith('bound')].copy()
            unb[non_key_cols] *= -1
            comb = pd.concat([unb, bnd], ignore_index=True)
            grp_sum = comb.groupby(['case_name','backrub_steps','struct_num','score_function_name'])[non_key_cols].sum().reset_index()
            grp_mean = grp_sum.groupby(['case_name','backrub_steps','score_function_name'])[non_key_cols].mean().round(5).reset_index()
            grp_mean['nstruct'] = n
            grp_mean['scored_state'] = f"{state}_dG"
            out.append(grp_mean)
    return out

def analyze(root: Path) -> None:
    jobs = {k: v for k, v in find_finished_jobs(root).items() if v}
    if not jobs:
        logging.warning("No completed structure cases found in: %s", root)
        return
    all_structs, all_ddg, all_other = [], [], []
    for case_dir, structs in jobs.items():
        dfs = [process_struct(p, case_dir.name) for p in structs]
        scores = pd.concat(dfs, ignore_index=True)
        ddg, full = calc_ddg(scores)
        all_structs.append(full)
        all_ddg.append(ddg)
        all_ddg.append(apply_zemu_gam(ddg))
        all_other.extend(calc_dgs(scores))
    OUTPUT_DIR.mkdir(exist_ok=True)
    base = root.name
    pd.concat(all_structs, ignore_index=True).to_csv(OUTPUT_DIR / f"{base}-struct_scores.csv", index=False)
    final = pd.concat(all_ddg + all_other, ignore_index=True)
    final.to_csv(OUTPUT_DIR / f"{base}-results.csv", index=False)

    # Saturation summary: average total_score per state
    max_n = final['nstruct'].max()
    summary = (
        final.groupby(['case_name','scored_state'])['total_score']
             .mean()
             .unstack(fill_value=np.nan)
             .reset_index()
    )
    summary.to_csv(OUTPUT_DIR / f"{base}-saturation_summary.csv", index=False)
    logging.info("Saturation summary (nstruct=%d) written to %s-saturation_summary.csv", max_n, base)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
    parser = argparse.ArgumentParser(description="Analyze Rosetta ddG output directories.")
    parser.add_argument('folders', nargs='+', type=Path, help='Dirs to process')
    args = parser.parse_args()
    for folder in args.folders:
        if folder.is_dir():
            analyze(folder)
        else:
            logging.error("Not a directory: %s", folder)
